ICOER_CONFIG = {
    "language": "portuguese",
    "lemmatization": True,
    "stopwords": True,
    "min_token_length": 3,
    "embedding_model": "all-MiniLM-L6-v2"
}
